﻿using System;
namespace u2
{
    public interface ITransform
    {
        string text { get; set; }
        string Transform();
    }

    
}
